#HW Basketball

library(shiny)
library(tidyverse)
library(ggplot2)
library(stringr)
library(shinyWidgets)
library(scales)
library(plotly)
library(htmlwidgets)

nbaSalaries <- read_csv("nbaSalaries.csv")
advanced1920 <- read_csv("2019.2020advancedStats.csv")
perGame1920 <- read_csv("2019.2020perGameStats.csv")

statsPlayers <- c() # list of all the players in perGame1920 (perGame1920 and advanced1920 have the same players)


for (i in 1:nrow(perGame1920)) {
    statsPlayers <- c(statsPlayers, perGame1920$Player[i])
}

salaryPlayers <- c()
for (j in 1:nrow(nbaSalaries)) {
    salaryPlayers <- c(salaryPlayers, perGame1920$Player[j])
}

nbaSalariesFiltered <- nbaSalaries %>% 
    filter(Player %in% statsPlayers) %>% 
    select(Player, `2019-20`, `2020-21`, `2021-22`, `2022-23`, `2023-24`, `2024-25`, `Guaranteed\\`)

# remove punctuation from entries in Guaranteed column
nbaSalariesFiltered$Guaranteed <- str_remove(nbaSalariesFiltered$`Guaranteed\\`,
                                             "[:punct:]")
nbaSalariesFiltered <- nbaSalariesFiltered %>% 
    select(Player, `2019-20`, `2020-21`, `2021-22`, `2022-23`, `2023-24`, `2024-25`, Guaranteed)

perGame1920Filtered <- perGame1920 %>% 
    select(!GS)

advanced1920Filtered <- advanced1920 %>% 
    select(Player, PER, `TS%`, `USG%`, OBPM, DBPM, BPM)

# joined nbaSalaries with perGame1920
salaryAndPerGame <- left_join(nbaSalariesFiltered,
                              perGame1920Filtered,
                              by = "Player")

# joined salaryAndPerGame with advanced1920
allData <- left_join(salaryAndPerGame,
                     advanced1920Filtered,
                     by = "Player")

options(scipen = 50000000, digits = 10)

# get rid of \
colnames(allData) <- str_replace_all(colnames(allData),
                                     "\\\\",
                                     "")
allData$PTS <- str_remove(allData$PTS,
                          "\\\\")

# change '3' to 'three'
colnames(allData) <- str_replace_all(colnames(allData),
                                     "3",
                                     "three")
# change '%' to 'Percent'
colnames(allData) <- str_replace_all(colnames(allData),
                                     "%",
                                     "Percent")

# rename columns
colnames(allData) <- c('Player', 'szn2020', 'szn2021', 'szn2022', 'szn2023', 'szn2024', 'szn2025', 'Guaranteed', 'Position', 'Age', 'Team', 
                       'GamesPlayed', 'MinutesPlayed', 'FGM', 'FGA', 'FGPercent', 'ThreePointersMade', 'ThreePointAttempts', 'ThreePointPercent', 
                       'TwoPointersMade', 'TwoPointAttempts', 'TwoPointPercent', 'eFGPercent', 'FTM', 'FTA', 'FTPercent', 'ORB', 'DRB', 'TRB', 'AST', 
                       'STL', 'BLK', 'TOV', 'PF', 'PTS', 'PER', 'TSPercent', 'USG', 'OBPM', 'DBPM', 'BPM')

# Put this in to get rid of everything after the \\ in the player names
allData$Player <- sub("\\\\.*", "", allData$Player)

# make Pts numerical instead of categorical
allData$PTS <- as.numeric(allData$PTS)

allData2 <- allData %>% 
    select(Player, szn2020, szn2021, szn2022, szn2023, szn2024, Guaranteed, PTS, AST, ORB, DRB, TRB, STL, BLK, TOV, PF, FGM, FGA, FGPercent, FTM, FTA, FTPercent, ThreePointersMade, ThreePointAttempts, ThreePointPercent, 
           TwoPointersMade, TwoPointAttempts, TwoPointPercent, GamesPlayed, MinutesPlayed, PER, eFGPercent, TSPercent, USG, OBPM, DBPM, BPM)

ui <- fluidPage(
    titlePanel(h1(id = "heading", "NBA Statistics vs. Salary (By Year)", align = "center")),
    tags$style(HTML("#heading{color: ghostwhite;}")),
    setBackgroundColor(
        color = c("#F6FBFB", "orange"),
        gradient = "linear",
        direction = "top"
    ),
    sidebarLayout(
        sidebarPanel(
            selectizeInput(inputId = "var1",
                           label = "Choose a statistic to plot against salaries",
                           choices = colnames(allData2)[-(1:7)]),
            p("Statistic Explanations",
              br(), 
              br(),
              "•FGM = Field Goals Made / Game",
              br(),
              "•eFGPercent = Weighted measure of field goal percentage to account for the fact that three pointers count for more points than two pointers",
              br(),
              "•FTM = Free Throws Made / Game",
              br(),
              "•FTA = Free Throw Attempts / Game",
              br(),
              "•ORB = Offensive Rebounds / Game",
              br(),
              "•DRB = Defensive Rebounds / Game",
              br(),
              "•TRB = Total Rebounds / Game",
              br(),
              "•PER = Measure of per-minute productivity, summing up a player's positive stats and subtracting negative stats during a game",
              br(),
              "•TSPercent = A measure of scoring efficiency based on the number of points scored over the number of possessions in which they attempted to score",
              br(),
              "•USG = Measure of how much a player is used when on the court",
              br(),
              "•OBPM = Measure of the average # of points a player's team scores per 100 possessions when a specific player is on the court",
              br(),
              "•DBPM = Measure of the average # of points a player's team allows per 100 possessions when a specific player is on the court",
              br(),
              "•BPM = Measure of the average point differential per 100 possessions when a specific player is on the court")),
        mainPanel(
            tabsetPanel(
                tabPanel("Background", span(strong("This application analyzes the relationship between NBA player salaries (according to their current 
                                       guaranteed contracts) and various basektball statistics recorded during the 2019-2020 NBA season. 
                                       Many of the top players have contracts that guarantee salaries for seasons further into the future."), 
                                       style = "color:white")),
                tabPanel("2020-2021 SZN", plotlyOutput(outputId = "plot1")),
                tabPanel("2021-2022 SZN", plotlyOutput(outputId = "plot2")),
                tabPanel("2022-2023 SZN", plotlyOutput(outputId = "plot3")),
                tabPanel("2023-2024 SZN", plotlyOutput(outputId = "plot4")),
                tabPanel("2024-2025 SZN", plotlyOutput(outputId = "plot5")),
                tabPanel("2025-2026 SZN", plotlyOutput(outputId = "plot6"))
            )
        )
    )
)

server <- function(input, output) {
    output$plot1 <- renderPlotly({
        scatterplot1 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2020",
                              text = paste('Player'))) + 
            geom_point() + 
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot1, tooltip = c("text"))
    })
    output$plot2 <- renderPlotly({
        scatterplot2 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2021",
                              text = paste('Player'))) + 
            geom_point() +
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot2, tooltip = c("text"))
    })
    output$plot3 <- renderPlotly({
        scatterplot3 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2022",
                              text = paste('Player'))) + 
            geom_point() +
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot3, tooltip = c("text"))
    })
    output$plot4 <- renderPlotly({
        scatterplot4 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2023",
                              text = paste('Player'))) + 
            geom_point() + 
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot4, tooltip = c("text"))
    })
    output$plot5 <- renderPlotly({
        scatterplot5 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2024",
                              text = paste('Player'))) + 
            geom_point() + 
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot5, tooltip = c("text"))
    })
    output$plot6 <- renderPlotly({
        scatterplot6 <- allData %>%  
            ggplot(aes_string(x = input$var1,
                              y = "szn2025",
                              text = paste('Player'))) + 
            geom_point() +
            labs(y = "Salary") +
            theme_bw() + 
            scale_y_continuous(labels = comma, breaks=seq(0, 60000000, by = 5000000),
                               limits = c(0,60000000))
        
        ggplotly(scatterplot6, tooltip = c("text"))
    })
}

# Run the application 
shinyApp(ui = ui, server = server)

